---
name: Icon request
about: Suggest an new icon for this project
---

<!--
Before creating an icon request, please search to see if someone has requested the icon already. If there is an open request, please add a 👍.
-->

## Icon Request

* Icon name:
* Use case:
* Screenshots of similar icons:
